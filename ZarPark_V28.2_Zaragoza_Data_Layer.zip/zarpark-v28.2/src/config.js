export const sources = {
  zaragoza: {
    cityId: "zaragoza",
    officialCatalog: "https://www.zaragoza.es/web/espacio-de-datos/servicio/catalogo/332",
    regulatedSegmentsWgs84:
      "https://www.zaragoza.es/trafico/estacionamiento/vias_estacionamiento_regulado_web_WGS84.json",
    regulatedZonesWgs84:
      "https://www.zaragoza.es/trafico/estacionamiento/zona_estacionamiento_regulado_WGS84.json",
    occupation:
      "https://www.zaragoza.es/trafico/estacionamientoots/Occupation.json"
  }
};
