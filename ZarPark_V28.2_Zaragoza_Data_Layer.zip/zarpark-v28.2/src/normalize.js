export function normalizeFeature(feature, providerId = "zaragoza-regulated") {
  const p = feature?.properties ?? {};
  const geometry = feature?.geometry;

  return {
    externalId: String(p.id ?? p.fid ?? p.codigo ?? `${p.nombre ?? "segment"}-${JSON.stringify(geometry).slice(0, 80)}`),
    providerId,
    streetName: p.nombre ?? p.NOMBRE ?? p.nombre_via ?? p.descripcion ?? "Vía regulada",
    segmentLabel: p.descripcion ?? p.DESCRIPCION ?? p.titulo ?? null,
    geometry,
    sourceProperties: p
  };
}

export function normalizeGeoJson(input, providerId) {
  const features = Array.isArray(input?.features) ? input.features : [];
  return features
    .filter(f => f?.geometry)
    .map(f => normalizeFeature(f, providerId));
}

export function normalizeOccupation(input) {
  const rows = Array.isArray(input)
    ? input
    : Array.isArray(input?.result)
      ? input.result
      : Array.isArray(input?.data)
        ? input.data
        : [];

  return rows.map(row => ({
    externalId: String(row.id ?? row.ID ?? row.codigo ?? row.CODIGO ?? ""),
    occupancyRate: normalizePercent(row.porcentaje ?? row.PORCENTAJE ?? row.occupation ?? row.ocupacion),
    observedAt: row.fecha ?? row.FECHA ?? row.timestamp ?? row.TIMESTAMP ?? new Date().toISOString(),
    raw: row
  })).filter(x => x.externalId);
}

function normalizePercent(value) {
  if (value === null || value === undefined || value === "") return null;
  const n = Number(String(value).replace(",", "."));
  if (!Number.isFinite(n)) return null;
  return n > 1 ? Math.max(0, Math.min(1, n / 100)) : Math.max(0, Math.min(1, n));
}
