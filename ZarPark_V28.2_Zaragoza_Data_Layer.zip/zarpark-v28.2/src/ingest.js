import { sources } from "./config.js";
import { normalizeGeoJson, normalizeOccupation } from "./normalize.js";

async function getJson(url) {
  const response = await fetch(url, {
    headers: { "Accept": "application/json" }
  });
  if (!response.ok) throw new Error(`${response.status} ${response.statusText}: ${url}`);
  return response.json();
}

export async function ingestZaragoza() {
  const s = sources.zaragoza;

  const [segments, zones, occupation] = await Promise.all([
    getJson(s.regulatedSegmentsWgs84),
    getJson(s.regulatedZonesWgs84),
    getJson(s.occupation)
  ]);

  return {
    cityId: s.cityId,
    fetchedAt: new Date().toISOString(),
    segments: normalizeGeoJson(segments, "zaragoza-regulated-segments"),
    zones: normalizeGeoJson(zones, "zaragoza-regulated-zones"),
    occupation: normalizeOccupation(occupation)
  };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  ingestZaragoza()
    .then(data => {
      console.log(JSON.stringify({
        cityId: data.cityId,
        fetchedAt: data.fetchedAt,
        segments: data.segments.length,
        zones: data.zones.length,
        occupationRecords: data.occupation.length
      }, null, 2));
    })
    .catch(error => {
      console.error(error);
      process.exitCode = 1;
    });
}
