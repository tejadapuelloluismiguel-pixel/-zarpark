// Public API contract consumed by iPhone/Android.
// The client never needs to know where the original municipal data came from.

export const parkingResponseExample = {
  cityId: "zaragoza",
  generatedAt: "2026-10-07T10:00:00Z",
  segments: [
    {
      id: "zaragoza-segment-123",
      streetName: "Calle Ejemplo",
      segmentLabel: "21-25",
      precisionLevel: "SEGMENT",
      observation: {
        occupancyRate: 0.62,
        observedAt: "2026-10-07T09:59:00Z",
        sourceQuality: 0.95
      }
    }
  ]
};
