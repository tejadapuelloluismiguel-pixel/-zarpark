# ZarPark V28.2 — Zaragoza Real Data Layer

Purpose:
Replace V28.1 demo parking segments with a provider-adapter layer for official Zaragoza data.

Important:
- The mobile app must NOT call the Ayuntamiento directly.
- Ingestion retrieves external data.
- Normalization converts it to ZarPark's generic model.
- The API/cache serves the mobile clients.
- Real-time occupancy must carry timestamp/source-quality metadata.
- A street segment means "parking is regulated/known here", NOT "a free space is guaranteed here".

Official source families currently targeted:
- Vías de Estacionamiento Regulado (WGS84)
- Zonas de Estacionamiento Regulado (WGS84)
- Porcentaje de Ocupación
- Zaragoza road network / street data
- Additional mobility restrictions/road works where useful

The source catalog is maintained separately so other Spanish cities and countries can be added without changing the core engine.
