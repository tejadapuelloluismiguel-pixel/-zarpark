import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import './style.css';

const ZARAGOZA = [-0.8891, 41.6488];
const MAP_STYLE = 'https://tiles.openfreemap.org/styles/bright';

const map = new maplibregl.Map({
  container: 'map',
  style: MAP_STYLE,
  center: ZARAGOZA,
  zoom: 13.2,
  attributionControl: true
});

map.addControl(new maplibregl.NavigationControl({showCompass: true}), 'bottom-right');

const status = document.getElementById('status');
const coords = document.getElementById('coords');
let userMarker = null;
let watchId = null;

const demoSegments = {
  type: 'FeatureCollection',
  features: [
    {
      type: 'Feature',
      properties: { id: 'demo-1', street: 'Tramo de prueba ZarPark 1' },
      geometry: { type: 'LineString', coordinates: [[-0.891,41.649],[-0.887,41.650]] }
    },
    {
      type: 'Feature',
      properties: { id: 'demo-2', street: 'Tramo de prueba ZarPark 2' },
      geometry: { type: 'LineString', coordinates: [[-0.894,41.647],[-0.891,41.646]] }
    }
  ]
};

map.on('load', () => {
  map.addSource('parking-segments', { type: 'geojson', data: demoSegments });
  map.addLayer({
    id: 'parking-segments-line',
    type: 'line',
    source: 'parking-segments',
    paint: {
      'line-color': '#1683ff',
      'line-width': 5,
      'line-opacity': 0.82
    }
  });

  status.textContent = 'Mapa listo. Activa Mi ubicación para comenzar.';
});

function updatePosition(position) {
  const { latitude, longitude, accuracy, heading } = position.coords;
  const lngLat = [longitude, latitude];

  if (!userMarker) {
    const el = document.createElement('div');
    el.className = 'user-dot';
    userMarker = new maplibregl.Marker({ element: el }).setLngLat(lngLat).addTo(map);
  } else {
    userMarker.setLngLat(lngLat);
  }

  coords.textContent =
    `${latitude.toFixed(6)}, ${longitude.toFixed(6)} · ±${Math.round(accuracy)} m` +
    (Number.isFinite(heading) ? ` · rumbo ${Math.round(heading)}°` : '');

  status.textContent = 'GPS activo. Siguiendo tu ubicación.';
}

function startLocation() {
  if (!navigator.geolocation) {
    status.textContent = 'Este dispositivo no permite geolocalización.';
    return;
  }

  if (watchId !== null) navigator.geolocation.clearWatch(watchId);

  watchId = navigator.geolocation.watchPosition(
    updatePosition,
    (error) => {
      status.textContent =
        error.code === error.PERMISSION_DENIED
          ? 'Necesitamos permiso de ubicación para navegar contigo.'
          : 'No hemos podido obtener una posición GPS fiable.';
    },
    { enableHighAccuracy: true, maximumAge: 1000, timeout: 10000 }
  );
}

document.getElementById('locate').addEventListener('click', startLocation);
